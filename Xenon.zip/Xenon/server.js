const express = require('express');
const mysql = require('mysql2');
const app = express();
const port = 3000;

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'xendb',
  connectionLimit: 10
});

// Set up the view engine
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Middleware to parse JSON data
app.use(express.json());

// Serve static files from the "public" directory
app.use(express.static(__dirname + '/public'));

// Route for the homepage
app.get('/', (req, res) => {
  // Fetch bike data from the database
  pool.query('SELECT * FROM bikes', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.sendStatus(500);
      return;
    }
    res.render('index', { bikes: results });
  });
});

// Route for the login page
app.get('/login', (req, res) => {
  res.render('login');
});

// Route for handling login form submission
app.post('/login', (req, res) => {
  // Process login form data and authenticate user
  const { username, password } = req.body;
  
  // Validate username and password
  // Perform authentication logic
  
  // Assuming authentication is successful
  res.redirect('/');
});

// Route for the contact us page
app.get('/contact', (req, res) => {
  res.render('contact');
});

// Route for handling contact form submission
app.post('/contact', (req, res) => {
  // Process contact form data and save it to the database
  const { name, email, message } = req.body;
  
  // Save the contact form data to the database
  pool.query('INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)', [name, email, message], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.sendStatus(500);
      return;
    }
    res.redirect('/contact');
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
