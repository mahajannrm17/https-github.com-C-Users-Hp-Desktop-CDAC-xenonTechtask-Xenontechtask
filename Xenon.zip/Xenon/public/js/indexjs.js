// Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Get all the bike elements
    var bikeElements = document.querySelectorAll('.bike');
  
    // Add click event listener to each bike element
    bikeElements.forEach(function(bikeElement) {
      bikeElement.addEventListener('click', function() {
        // Toggle active class on the clicked bike element
        this.classList.toggle('active');
      });
    });
  });
  