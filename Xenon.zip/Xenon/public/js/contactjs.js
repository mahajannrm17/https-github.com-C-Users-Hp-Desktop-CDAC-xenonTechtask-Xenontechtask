// Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Get the contact form element
    var contactForm = document.getElementById('contactForm');
  
    // Add submit event listener to the contact form
    contactForm.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent form submission
  
      // Get the form data
      var formData = new FormData(contactForm);
  
      // Send the form data to the server
      fetch('/contact', {
        method: 'POST',
        body: formData
      })
      .then(function(response) {
        // Handle the response from the server
        if (response.ok) {
          // Display a success message
          alert('Message sent successfully!');
          contactForm.reset(); // Reset the form
        } else {
          // Display an error message
          alert('Oops! Something went wrong. Please try again.');
        }
      })
      .catch(function(error) {
        console.error('Error:', error);
      });
    });
  });
  