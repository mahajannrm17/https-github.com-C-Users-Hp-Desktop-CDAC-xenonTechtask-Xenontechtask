// Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Get the login form element
    var loginForm = document.getElementById('loginForm');
  
    // Add submit event listener to the login form
    loginForm.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent form submission
  
      // Get the form data
      var formData = new FormData(loginForm);
  
      // Send the form data to the server
      fetch('/login', {
        method: 'POST',
        body: formData
      })
      .then(function(response) {
        // Handle the response from the server
        if (response.ok) {
          // Display a success message
          alert('Login successful!');
          loginForm.reset(); // Reset the form
        } else {
          // Display an error message
          alert('Invalid username or password. Please try again.');
        }
      })
      .catch(function(error) {
        console.error('Error:', error);
      });
    });
  });
  